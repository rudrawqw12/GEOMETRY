// const firstName = "Rokib";
// const lastName = "hasan";

// const fullName = `${firstName} ${lastName} ${7 + 5}`;
// console.log(fullName);

// function add(l, z) {
//   // let l = 10
//   return l + z;
// }

// let x = 7;
// let y = 10;
// console.log(add(x, y));

// let p = 10;
// let n = 20;
// console.log(add(p, n));
